import pyttsx3
import speech_recognition as sr
import eel
import time

def speak(text):
    """ Convert text to speech and display it in the frontend using eel. """
    text = str(text)
    engine = pyttsx3.init('sapi5')
    voices = engine.getProperty('voices') 
    engine.setProperty('voice', voices[0].id)
    engine.setProperty('rate', 174)  # Adjust speech rate
    eel.DisplayMessage(text)  # Send to frontend
    engine.say(text)
    eel.receiverText(text)  # Display received text in frontend
    engine.runAndWait()

def take_audio_input():
    """Listen for audio input and return the recorded audio."""
    r = sr.Recognizer()
    try:
        with sr.Microphone() as source:
            print('Listening for your command...')
            eel.DisplayMessage('Listening for your command...')
            
            r.adjust_for_ambient_noise(source, duration=1)  # Adjust to ambient noise
            eel.DisplayMessage('Adjusted for ambient noise, please speak now.')
            
            r.pause_threshold = 1  # End listening if there's a pause
            
            audio = r.listen(source, timeout=10, phrase_time_limit=6)  # Listen for speech
            eel.DisplayMessage('Processing your command...')
            print('Processing your command...')
            return audio
    
    except sr.WaitTimeoutError:
        eel.DisplayMessage('Listening timed out, please try again.')
        print('Listening timed out, please try again.')
        return None
    
    except Exception as e:
        eel.DisplayMessage(f"An error occurred: {e}")
        print(f"An error occurred: {e}")
        return None


def recognize_speech(audio):
    """Use Google Speech Recognition to convert audio to text."""
    r = sr.Recognizer()
    try:
        eel.DisplayMessage('Recognizing...')
        query = r.recognize_google(audio, language='en-in')
        print(f"User said: {query}")
        eel.DisplayMessage(query)  # Show recognized text in frontend
        time.sleep(2)
        return query.lower()
    
    except sr.UnknownValueError:
        eel.DisplayMessage("Sorry, I didn't catch that. Please try again.")
        print("Google Speech Recognition could not understand audio.")
        return ""
    
    except sr.RequestError as e:
        eel.DisplayMessage(f"Could not request results; {e}")
        print(f"Could not request results; {e}")
        return ""


@eel.expose
def allCommands(message=1):
    """Main function that handles voice or text input commands, processes them, and interacts with various features."""
    query = ""
    if message == 1:
        audio = take_audio_input()
        if audio:
            query = recognize_speech(audio)
        eel.senderText(query)
    else:
        query = message
        eel.senderText(query)
    
    try:
        if "open" in query:
            from engine.features import openCommand
            openCommand(query)
        elif "on youtube" in query:
            from engine.features import PlayYoutube
            PlayYoutube(query)
        
        elif "send message" in query or "phone call" in query or "video call" in query:
            from engine.features import findContact, whatsApp, makeCall, sendMessage
            contact_no, name = findContact(query)
            if contact_no != 0:
                speak("Which mode you want to use: WhatsApp or mobile?")
                preference = take_audio_input()
                print(preference)

                if "mobile" in preference:
                    if "send message" in query or "send sms" in query: 
                        speak("What message to send?")
                        message = take_audio_input()
                        sendMessage(message, contact_no, name)
                    elif "phone call" in query:
                        makeCall(name, contact_no)
                    else:
                        speak("Please try again.")
                elif "whatsapp" in preference:
                    message_type = ""
                    if "send message" in query:
                        message_type = 'message'
                        speak("What message to send?")
                        query = take_audio_input()
                    elif "phone call" in query:
                        message_type = 'call'
                    else:
                        message_type = 'video call'
                    whatsApp(contact_no, query, message_type, name)

        else:
            from engine.features import chatBot
            chatBot(query)

    except Exception as e:
        print(f"Error encountered: {e}")
    
    eel.ShowHood()  # Update frontend


